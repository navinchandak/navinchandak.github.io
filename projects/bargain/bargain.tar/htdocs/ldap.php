<?php
	include"db.inc.php";
	include "checkbids.php";
	header ("Location: ./addUser.html");
	checkBids();
	$ldap_id = $_POST['username'];
	$ldap_password = $_POST['password'];
	$ds = ldap_connect("ldap.iitb.ac.in") or die("Unable to connect to LDAP server. Please try again later.");
	if($ldap_id == '') 
	{
		die("You have not entered any LDAP ID. Please go back and fill it up.");
	}
	$sr = ldap_search($ds,"dc=iitb,dc=ac,dc=in","(uid=$ldap_id)");
	$info = ldap_get_entries($ds, $sr);
	if(empty($info[0]['dn'])) {
		echo "haha,lol";
		header("Refresh: 1; url=login.php");
	}
	else {
		
		$ldap_id_bind = $info[0]['dn'];
		if(@ldap_bind($ds, $ldap_id_bind, $ldap_password))
		{
			//echo "Success";
			$expire = time () + 60 * 60 * 24;
			setcookie ("user", "$ldap_id", $expire);
			
			$flag=0;
			$result = mysqli_query($link,"SELECT ldapid from user");
			while($row = mysqli_fetch_array($result)) {
				if( $row['ldapid'] ==$ldap_id) {
					$flag=1; break; 
					}
			}
			
			if($flag==0) {
				header("Location: ./addUser.html");
				}
			else 
			{header ("Location: ./bumble/index.php");
			}
		}
	}
	
?>