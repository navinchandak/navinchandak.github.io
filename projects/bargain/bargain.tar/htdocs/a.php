<?php
	include"db.inc.php";
	$sql="INSERT INTO user (ldapid, fn, ln, email,ph,addr, interests,following) VALUES ('$_COOKIE[user]','$_POST[fn]','$_POST[ln]','$_POST[email]','$_POST[ph]','$_POST[addr]','$_POST[interests]','')";
	mysqli_query($link,$sql);
	header("Location: ./bumble/index.php");
?>	
  
  
  
  
  
  
