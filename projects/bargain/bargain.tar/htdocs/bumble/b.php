<?php

	date_default_timezone_set ('Asia/Kolkata');
	function error ($error)
	{
		//header ("Refresh: 1; URL = 'insertItem.php'");
		echo $error;
		exit;
	}
	
	$max_file_size = 2097152;
	$current_directory = str_replace(basename($_SERVER['PHP_SELF']) , '' , $_SERVER['PHP_SELF']);
	$upload_form = 'http://' . $_SERVER['HTTP_HOST'] . $current_directory . 'insertItem.php';
	$fieldname = 'image_path';
	$errors = array (1 => "Max file size exceeded", 2 => "Max file size exceeded", 3 => "Upload incomplete", 4 => "No file attached");
	isset ($_POST['submit']) or error ("Redirecting to upload form", $upload_form);
	($_FILES[$fieldname]['error'] == 0) or error ($errors[$_FILES[$fieldname]['error']], $upload_form);
	@is_uploaded_file($_FILES[$fieldname]['tmp_name']) or error ("Not an HTTP upload", $upload_form);
	@getimagesize($_FILES[$fieldname]['tmp_name']) or error ("Please upload only images", $upload_form);
	$uploaded_directory = $_SERVER ['DOCUMENT_ROOT'] . $current_directory . 'images/';
	$time=gmdate("YmdHis");	
	$new_file_name = $_COOKIE['user']  . $time . str_replace(' ', '_', $_FILES[$fieldname]['name']);
	if (file_exists($uploaded_directory . $new_file_name))
	{
		error ("File exists", $upload_form);
	}
	$uploadedfile = $_FILES[$fieldname]['tmp_name'];
	$image = getimagesize($uploadedfile);
	if (($image['mime'] == 'image/jpeg') || ($image['mime'] == 'image/pjpeg'))
	{
		$src = imagecreatefromjpeg($uploadedfile);
	}
	else if ($image['mime'] == 'image/gif')
	{
		$src = imagecreatefromgif($uploadedfile);
	}
	else if ($image['mime'] == 'image/png')
	{
		$src = imagecreatefrompng($uploadedfile);
	}
	list($width,$height)=getimagesize($uploadedfile);
	$new_width=200;
	$new_height=150;
	$tmp = imagecreatetruecolor ($new_width, $new_height);
	imagecopyresampled ($tmp, $src, 0, 0, 0, 0, $new_width, $new_height, $width, $height);
	imagejpeg ($tmp, $uploaded_directory . $new_file_name, 100);
	imagedestroy($src);
	imagedestroy($tmp);
	include "./db.inc.php";
	$time=gmdate("YmdHis");	
	$sql="INSERT INTO item (name, category,description , tags,link,base, bid_time, buy_it_now, current_bid, no_of_bids, owner,followers, time_intro, high_bid,image_path) VALUES ('$_POST[name]','$_POST[category]','$_POST[description]','$_POST[tags]','$_POST[link]',$_POST[base],'$_POST[bid_time]',$_POST[buy_it_now],0,0,'$_COOKIE[user]','$_COOKIE[user]',$time,'','$new_file_name')";
	mysqli_query ($link,$sql);
	
	//mysqli_query($link, "insert into item(name) values ('navin');");
	//$row = mysqli_fetch_array($result);
	//echo $row['id'];
	
	
	header("Location: ./index.php");
?>