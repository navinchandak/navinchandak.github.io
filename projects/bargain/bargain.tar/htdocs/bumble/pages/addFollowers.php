<?php
 function addFollowers($id) {
	include 'db.inc.php';
	$sql1 = "SELECT email, following FROM user WHERE ldapid = '$_COOKIE[user]'";
	$q1 = mysqli_query ($link, $sql1);
	$row = mysqli_fetch_array ($q1);
	$following = $row['following'];
	if(!strstr($following, $id)) {
		$following = $following." ". $id; 
	}
	$sql2 = "UPDATE user SET following = $following WHERE ldapid = '$_COOKIE[user]'";
	$q2 = mysqli_query($link, $sql2);
	$sql3 = "SELECT followers FROM item WHERE id = $id";
	$q3 = mysqli_query ($link, $sql3);
	$row1 = mysqli_fetch_array ($q3);
	$followers = $row1['followers'];
	if(!strstr($followers, $row['email'])) {
		$followers.= $row['email'];
	}
	$sql4 = "UPDATE item SET followers = $followers WHERE id = $id";
	$q4 = mysqli_query ($link, $sql4);
	}
	?>