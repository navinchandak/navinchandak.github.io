<?php
	include "db.inc.php";
	include "sendmail.php";
	$result = mysqli_query($link,"SELECT * from item where id='$_POST[itemid]'");
	mysqli_query($link,"update item set high_bid='$_COOKIE[user]' where id='$_POST[itemid]'");
	$row = mysqli_fetch_array($result);
	sendmail($row);
	$result = mysqli_query($link,"SELECT image_path from item where id='$_POST[itemid]'");
	$row = mysqli_fetch_array($result);
	unlink("images/$row[image_path]");
	$result = mysqli_query($link,"DELETE from item where id=$_POST[itemid]");

	?>