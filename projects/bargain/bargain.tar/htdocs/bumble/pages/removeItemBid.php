<?php
	include "db.inc.php";
	
	$result = mysqli_query($link,"SELECT image_path from item where id='$_POST[itemid]'");
	$row = mysqli_fetch_array($result);
	unlink("../images/$row[image_path]");
	$result = mysqli_query($link,"DELETE from item where id=$_POST[itemid]");
	echo "done";
	header('refresh:2; url=../index.php');
	?>