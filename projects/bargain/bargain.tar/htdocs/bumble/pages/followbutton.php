﻿<?php
	include "followers.php";
	addFollowers($_POST['itemid']);
	echo "done";
	header('refresh:1; url=../index.php');
?>