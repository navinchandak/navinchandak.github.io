<html>
<head>


</head>

<body>
<br/>

<font size="6">Everything.</font>

<br/>
<br/>
<br/>
<br/>

<?php
	include './db.inc.php';
	include './displayItem.php';
	$result = mysqli_query ($link,"SELECT * FROM item WHERE owner<>'$_COOKIE[user]'");
	while ($row = mysqli_fetch_array($result))
	{
		displayItem($row);
	}
?>



<!-- for each item; name category description tags linkForFurtherInformation BasePrice CurrentBid timeLeft BuyNowPrice #Bids Image-->
</head>
</html>

