<html>
<head>


</head>

<body>
<br/>
<br/>
<br/>
<font size="6">The Most Sought After Stuff</font>

<br/>
<br/>
<br/>
<br/>
<?php
	include './db.inc.php';
	include './displayItem.php';
	$result = mysqli_query ($link,"SELECT * FROM item WHERE owner != '$_COOKIE[user]' ORDER BY no_of_bids DESC LIMIT 5");
	while ($row = mysqli_fetch_array($result))
	{
		displayItem($row);
	}
?>
</body>



<!-- for each item; name category description tags linkForFurtherInformation BasePrice CurrentBid timeLeft BuyNowPrice #Bids Image-->
</head>
</html>