<?php
$link = mysqli_connect('localhost', 'root', 'abcde');
	if (!$link)
	{
		$error = "Unable to connect to the database server";
		include 'error.html.php';
		exit ();
	}
	if (!mysqli_set_charset ($link, 'utf8'))
	{
		$error = "Unable to set database connection encoding";
		include 'error.html.php';
		exit ();
	}
	if (!mysqli_select_db ($link, 'my_db'))
	{
		$error = "Unable to locate the bidding database";
		include 'error.html.php';
		exit ();
	}
?>