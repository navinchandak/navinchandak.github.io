<script type="text/javascript">
	function validateForm(t)
	{
		var x=document.forms["myForm"]["value"].value;
			if (x==null || x<=t)
		{
			alert("Bid Price must be greater than the current price");
			return false;
		}
	}
</script>



<?php
	function displayItem($arr) {
		$left= (($arr['time_intro']-gmdate('His'))/1000)+($arr['bid_time']*86400);
		$days=floor($left/(60*60*24));
		$hours=floor($left/(60*60)-($days*24));
		$min=floor(($left/60)-($hours*60)-($days*24*60));

	
	
	
		echo "<img height='150' width='200' align='left' style='padding:5px;' src='images/$arr[image_path]'/>";
		echo "Name: $arr[name]  <br/>";
		echo "Category: $arr[category] <br/> ";
		echo "Tags: $arr[tags] <br>";
		echo "External Links: $arr[link] <br>";
		echo "Base Price: $arr[base] <br>";
		if($arr['no_of_bids']==0) {
			 echo "No Bids till now.<br>";
			 }
		else {echo "Current Bid: $arr[current_bid] &nbsp; <br>";}
		echo "Buy Now Price: $arr[buy_it_now] <br/>";
		echo "Number of Bids: $arr[no_of_bids] <br/>";
		echo "Time left: ".$days." days,".$hours." hours,".$min." minutes<br/> <br/>";
		echo "Description: $arr[description] <br/> <br/>";
		if($arr['owner']==$_COOKIE['user']) {
			echo "<form  method='POST' action='./pages/removeItemBid.php' > <input type='hidden' name='itemid' value='$arr[id]'/> <input type='submit' value='Remove'/></form>";
			}
		else if(strstr($arr['followers'],$_COOKIE['user'])){
			echo "<form  method='POST' action='./pages/unfollow.php' > &nbsp;No longer interested in this item? : <input type='hidden' name='itemid' value='$arr[id]'/> <input type='submit' value='Unfollow'/></form>";
			echo "<form  method='POST' action='changeItemValue.php' onsubmit='return validateForm($arr[current_bid])' > &nbsp;Ready to bid?:<input type='text' name='value' /> <input type='hidden' name='itemid' value='$arr[id]'/> <input type='submit' value='Bid!'/></form>";
			echo "<form  method='POST' action='./pages/buyitnow.php'  > &nbsp;Buy it now?:<input type='hidden' name='itemid' value='$arr[id]'/> <input type='submit' value='Buy It Now!'/></form>";
		}
		else {
			echo "<form  method='POST' action='./pages/followbutton.php' > &nbsp;Follow this item? : <input type='hidden' name='itemid' value='$arr[id]'/> <input type='submit' value='Follow'/></form>";
			echo "<form  method='POST' action='./pages/changeItemValue.php' onsubmit='return validateForm($arr[current_bid])' > &nbsp;Ready to bid?: <input type='text' name='value' /> <input type='hidden' name='itemid' value='$arr[id]'/> <input type='submit' value='Bid!'/></form>";
			echo "<form  method='POST' action='./pages/buyitnow.php'  > &nbsp;Buy it now?:<input type='hidden' name='itemid' value='$arr[id]'/> <input type='submit' value='Buy It Now!'/></form>";
			}
		echo "<br/> <br/>";
		
		}

	?>