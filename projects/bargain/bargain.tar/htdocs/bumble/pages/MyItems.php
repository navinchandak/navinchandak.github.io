<html>
<head>


</head>

<body>
<br/>
<br>
<br>
<font size="6">Up for Bidding. From Your Side.</font>

<br/>
<br/>
<br/>
<br/>

<?php
	include"./db.inc.php";
	include "./displayItem.php";
	$result = mysqli_query($link,"SELECT * from item where owner='$_COOKIE[user]'");
	while($row = mysqli_fetch_array($result)) {
		displayItem($row);
	}
	
?>
	
	

</p>

<br/>

</body>



<!-- for each item; name category description tags linkForFurtherInformation BasePrice CurrentBid timeLeft BuyNowPrice #Bids Image-->
</head>
</html>