<h1>Test content</h1>
<p>Blabla</p>
<div class="leftLine">
Some content<br />
with a white stripe<br />
next to it<br />
</div>