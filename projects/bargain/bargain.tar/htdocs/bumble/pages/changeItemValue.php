<?php
	include "db.inc.php";
	include "mail.php";
	include "addFollowers.php";
	mysqli_query($link,"UPDATE item set current_bid=$_POST[value],high_bid='$_COOKIE[user]',no_of_bids=no_of_bids+1 where id=$_POST[itemid]");
	
	addFollowers($_POST['itemid']);
	$row= mysqli_fetch_array(mysqli_query($link,"select * from item where id=$_POST[itemid]"));
	$ids=explode(" ",$row['followers']);
	$name=$row['name'];
	for($i=0;$i<count($ids);$i++) {
		mail_people($ids[$i],'Item Bid Changed','The bid of item which you are following,i.e, $name has changed to $_POST[value]');
	}
	echo "done";
	header('refresh:1; url=../index.php');
	?>