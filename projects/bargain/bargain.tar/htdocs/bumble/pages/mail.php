﻿<?php
	function mail_people ($to, $subject, $body)
	{
		//mail ($to, $subject, $body, $headers);
	}
?>