<html>
	<body>
		<form name = "login" action = "ldap.php" method = "post">
			Username: <input type = "text" name = "username" id = "username">
			Password: <input type = "password" name = "password" id = "password">
			<input type = "submit" value = "Login">
		</form>
	</body>
</html>