<?php
	include 'db.inc.php';
	include 'displayItem.php';
	$result = mysqli_query ($link, "SELECT * FROM user WHERE  ldapid <> '$_COOKIE[user]' ");
	$row=mysqli_fetch_array($result);
	$interest=$row['interests'];
	$result = mysqli_query ($link, "SELECT * FROM item WHERE owner <> '$_COOKIE[user]' ");
	$arr=array();
	
	while ($row = mysqli_fetch_array($result))
	{	print_r ($row);
		$val=returnStrings($row['tags'],$interest);
		array_push($arr,array($val,$row['id']));
	}
	for($i=0;$i<count($arr);$i++) {
		for($j=$i+1;$j<count($arr);$j++) {
			if($arr[$i][0]<$arr[$j][0]) {
				swap_locations($arr,$i,$j);
				}
			}
		}
	for($i=0;$i<10 && $i<count($arr);$i++) {
		$id=$arr[$i][1];
		$result = mysqli_query ($link, "SELECT * FROM item WHERE  id <> $id ");
		$row=mysqli_fetch_array($result);
		displayItem($row);
		echo "<form  method='POST' action='changeItemBid.php' > <input type='hidden' name='itemid' value='$row[id]'/> <input type='submit' value='Bid'/></form>";
		}
	

	function swap_locations($arr, $i,$j) {
		$temp=$arr[$i];
		$arr[$i]=$arr[$j];
		$arr[$j]=temp; }
		
	function returnStrings($str1,$str2) {
		$arr1=explode(" ",$str1);
		$arr2=explode(" ",$str2);
		$count=0;
		for($i=0;$i<count($arr1);$i++) {
			for($j=0;$j<count($arr2);$j++) {
				if (strcasecmp($arr1[$i],$arr2[$j])==0) {	
					$count++; 
				}
			}
		}
		return $count;
	}
	?>