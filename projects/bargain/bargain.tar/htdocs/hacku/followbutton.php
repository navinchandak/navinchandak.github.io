﻿<?php
	include "followers.php";
	addFollowers($_POST['itemid']);
?>