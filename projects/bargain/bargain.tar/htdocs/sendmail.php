<?php 
		
		function sendmails($row) {
			include "db.inc.php";
			include "mail.php";
			$buyer=$row['high_bid'];
			$buyer = mysqli_query($link,"SELECT addr from user where ldapid='$buyer'");
			$buyerrow=mysqli_fetch_array($buyer);
			$owner=$row['high_bid'];
			$owner = mysqli_query($link,"SELECT addr from user where ldapid='$owner'");
			$ownerrow=mysqli_fetch_array($owner);
			mail_people("$row[owner]@iitb.ac.in","Ur Item Sold","$row[high_bid] has purchased your item $row[name]. His addr $buyerrow[addr] $buyerrow[ph]");
			mail_people("$row[high_bid]@iitb.ac.in", "Got the item", "You got your item $row[name] . Owners addr $ownerrow[addr] $ownerrow[ph]");
		}
?>