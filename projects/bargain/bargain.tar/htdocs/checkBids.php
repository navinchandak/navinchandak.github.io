<?php 
function checkBids() {
	include "db.inc.php";
	include "sendmail.php";
	$result = mysqli_query($link,"SELECT * from item");
	while($row = mysqli_fetch_array($result)) {
		$left= (($row['time_intro']-gmdate("His"))/1000)+($row['bid_time']*86400);
		if($left<0) {
			sendmails($row);
			unlink("images/$row[image_path]");
			$result = mysqli_query($link,"DELETE from item where id=$_POST[itemid]");
		}
	}
}
	?>